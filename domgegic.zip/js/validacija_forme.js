function trenutnaForma(){
    var trenutnaForma=document.getElementsByTagName("form")[0]["name"];
    if(typeof(trenutnaForma)=='undefined')return null;
    return trenutnaForma;
}

function validacija(){
    var greska="";
    var forma=trenutnaForma();

    switch(forma){
        case "natjecaj":
            var slika=document.getElementById("slika").value;
            var g=document.getElementsByClassName("error");

            if(slika==""){
                greska="Molim unesite url slike<br/>";
                g[0].innerHTML=greska;
            }
            break;
        case "kreiraj_natjecaj":
        case "azuriraj_natjecaj":
            var g=document.getElementsByClassName("error");

            var naziv=document.getElementById("naziv").value;
            var brm=document.getElementById("brm").value;
            var datumkreiranja=document.getElementById("datumkreiranja").value;
            var vrijemekreiranja=document.getElementById("vrijemekreiranja").value;
            var kratica=document.getElementById("kratica").value;
            if(naziv==""){
                greska="Molimo unesite naziv natjecaja.<br/>";
                g[0].innerHTML=greska;
            }
            else if(brm==""){
                greska="Molimo unesite broj radnih mjesta.<br/>";
                g[0].innerHTML=greska;
            }
            else if(datumkreiranja==""){
                greska="Molimo unesite datum kreiranja.<br/>";
                g[0].innerHTML=greska;
            }
            else if(vrijemekreiranja==""){
                greska="Molimo unesite vrijeme kreiranja.<br/>";
                g[0].innerHTML=greska;
            }
            else if(vrijemekreiranja==""){
                greska="Molimo unesite kraticu zupanije.<br/>";
                g[0].innerHTML=greska;
            }
            break;
        case "statistika":
            var g=document.getElementsByClassName("error");

            var datum_od=document.getElementById("datum_od").value;
            var datum_do=document.getElementById("datum_do").value;
            if (datum_od)
            {
                var datum_od=document.getElementById("datum_od").value.split('.');
                if (new Date(datum_od[2], datum_od[1], datum_od[0])=='Invalid Date'){
                    greska="Unesite ispravan format datuma za Datum od";
                    g[0].innerHTML=greska;
                }
            }
            if(datum_do){
                var datum_do=document.getElementById("datum_do").value.split('.');
                if (new Date(datum_do[2], datum_do[1], datum_do[0])=='Invalid Date'){
                    greska="Unesite ispravan format datuma za Datum do";
                    g[0].innerHTML=greska;
                }
            }else{
                return true;
            }
            break;
        case "azuriraj_zavod":
        case "kreiraj_zavod":
            var g=document.getElementsByClassName("error");

            var naziv=document.getElementById("naziv").value;
            var opis=document.getElementById("opis").value;

            if(naziv==""){
                greska="Molimo unesite naziv zavoda.<br/>";
                g[0].innerHTML=greska;
            }else if(opis==""){
                greska="Molimo unesite opis zavoda.<br/>";
                g[0].innerHTML=greska;
            }
            break;
        case "azuriraj_korisnika":
            var g=document.getElementsByClassName("error-form");

            var korisnicko_ime=document.getElementById("korisnicko_ime").value;
            var email=document.getElementById("email").value;

            if(korisnicko_ime==""){
                greska="Molimo unesite korisnicko ime.<br/>";
                g[0].innerHTML=greska;
            }else if(email==""){
                greska="Molimo unesite email.<br/>";
                g[0].innerHTML=greska;
            }else if(email.indexOf('@') == -1){
                greska="Molimo unesite ispravan email.<br/>";
                g[0].innerHTML=greska;
            }
            break;
        default:
            break;
    }
    if(greska.length!=0)return false;
    return true;
}